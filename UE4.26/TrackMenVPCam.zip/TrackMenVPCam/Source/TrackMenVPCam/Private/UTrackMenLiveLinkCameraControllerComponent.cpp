/* Copyright 2021 TrackMen GmbH <mail@trackmen.de> */

#include "UTrackMenLiveLinkCameraControllerComponent.h"

UTrackMenLiveLinkCameraControllerComponent::UTrackMenLiveLinkCameraControllerComponent() : ULiveLinkComponentController()
{

}