/* Copyright 2021 TrackMen GmbH <mail@trackmen.de> */

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "ExampleProjectGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class EXAMPLEPROJECT_API ALLMB_ExampleGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
	
	
	
};
