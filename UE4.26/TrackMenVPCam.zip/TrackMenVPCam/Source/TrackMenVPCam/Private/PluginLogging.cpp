/* Copyright 2021 TrackMen GmbH <mail@trackmen.de> */

#include "PluginLogging.h"

DEFINE_LOG_CATEGORY(LogTrackMenPlugin);