/* Copyright 2021 TrackMen GmbH <mail@trackmen.de> */

#include "ExampleProject.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, ExampleProject, "ExampleProject" );
