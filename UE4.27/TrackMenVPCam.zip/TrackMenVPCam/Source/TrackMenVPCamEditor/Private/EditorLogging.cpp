/* Copyright 2021 TrackMen GmbH <mail@trackmen.de> */

#include "EditorLogging.h"

DEFINE_LOG_CATEGORY(LogTrackMenEditor);